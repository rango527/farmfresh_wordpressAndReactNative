<?php
// This file was auto-generated from sdk-root/src/data/cloudtrail/2013-11-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeTrails', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DeleteTrail', 'input' => [ 'Name' => 'faketrail', ], 'errorExpectedFromService' => true, ], ],];
