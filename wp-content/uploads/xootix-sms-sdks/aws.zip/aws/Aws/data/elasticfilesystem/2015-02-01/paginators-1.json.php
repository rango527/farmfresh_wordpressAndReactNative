<?php
// This file was auto-generated from sdk-root/src/data/elasticfilesystem/2015-02-01/paginators-1.json
return [ 'pagination' => [],];
