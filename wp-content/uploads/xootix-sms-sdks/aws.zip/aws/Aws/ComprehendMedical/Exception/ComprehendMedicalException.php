<?php
namespace Aws\ComprehendMedical\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **AWS Comprehend Medical** service.
 */
class ComprehendMedicalException extends AwsException {}
